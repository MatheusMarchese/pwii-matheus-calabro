<?php
include("conexao.php");

$name     = $_POST['name'] ?? '';
$idade    = (int)($_POST['idade'] ?? 0);
$cpf      = $_POST['cpf'] ?? '';
$cell     = $_POST['cell'] ?? '';
$endereco = $_POST['endereço'] ?? '';
$sexo     = $_POST['sexo'] ?? '';

$inserir = $pdo->prepare("INSERT INTO demo (name, idade, cpf, cell, endereço, sexo) VALUES (:name, :idade, :cpf, :cell, :endereco, :sexo)");
$inserir->execute([
    ':name'     => $name,
    ':idade'    => $idade,
    ':cpf'      => $cpf,
    ':cell'     => $cell,
    ':endereco' => $endereco,
    ':sexo'     => $sexo
]);

header("Location: kaline.php");
exit();
?>
