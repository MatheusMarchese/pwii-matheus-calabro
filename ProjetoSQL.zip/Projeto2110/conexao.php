<?php

$username = "root";
$password = "";

$pdo = new PDO('mysql:host=localhost;dbname=bdpw3', $username, $password);

?>